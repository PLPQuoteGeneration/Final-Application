package com.cg.qgs.dao.implementation;

import static org.junit.Assert.assertEquals;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.qgs.dao.QueryMapper;
import com.cg.qgs.exception.QGSException;
import com.cg.qgs.utility.JdbcUtility;

public class QGSDaoImplementationTest {

	QGSDaoImplementationTest object = null;

	@Before
	public void setUp() throws Exception {
		object = new QGSDaoImplementationTest();
	}

	@After
	public void tearDown() throws Exception {
		object = null;
	}

	@Test
	public void testAddProfile() {
		int result = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = JdbcUtility.getConnection();
		} catch (QGSException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		try {
			preparedStatement = connection.prepareStatement(QueryMapper.addProfile);
			preparedStatement.setString(1,"indiradivvela");
			preparedStatement.setString(2, "indira12");
			preparedStatement.setString(3, "ADMIN123");

			result = preparedStatement.executeUpdate();
			connection.commit();
			assertEquals(result, 1);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		try {
			connection.rollback();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		e.printStackTrace();
	} finally {
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	}

	@Test
	public void testGeneratePolicy() {
		int result = 0;
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		
		try {
			connection = JdbcUtility.getConnection();
		} catch (QGSException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.generatePolicy);
			preparedStatement.setDouble(1, 1800.0);
			preparedStatement.setLong(2, 1000000004);
			preparedStatement.setString(3, "Restaurant");

			result = preparedStatement.executeUpdate();
			assertEquals(result, 1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test

	public void testPolicyDetails() {

	int result = 0;

	Connection connection = null;

	PreparedStatement preparedStatement = null;

	try {

	connection = JdbcUtility.getConnection();

	} catch (QGSException e1) {

	// TODO Auto-generated catch block

	e1.printStackTrace();

	}

	try {

	preparedStatement = connection.prepareStatement(QueryMapper.insertPolicyDetails);

	preparedStatement.setLong(1, 1000000006);

	preparedStatement.setString(2,"Property Size");

	preparedStatement.setString(3, "more than 10000 sq.ft");

	result = preparedStatement.executeUpdate();

	assertEquals(result, 1);

	} catch (SQLException e) {

	// TODO Auto-generated catch block

	e.printStackTrace();

	}

	}

	@Test

	public void testAddAccount() {

	Connection connection = null;

	PreparedStatement preparedStatement = null;

	try {

	connection = JdbcUtility.getConnection();

	} catch (QGSException e1) {

	// TODO Auto-generated catch block

	e1.printStackTrace();

	}

	int result = 0;

	try {

	preparedStatement = connection.prepareStatement(QueryMapper.addAccount);

	preparedStatement.setString(1, "Indira");

	preparedStatement.setString(2, "Hitech");

	preparedStatement.setString(3, "hyderabad");

	preparedStatement.setString(4, "telangana");

	preparedStatement.setLong(5, 50023);

	preparedStatement.setString(6, "admin");

	result = preparedStatement.executeUpdate();

	assertEquals(result, 1);


	} catch (SQLException e) {

	e.printStackTrace();

	}

	}



}
