package com.cg.qgs.dao.implementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.qgs.dao.QGSDao;
import com.cg.qgs.dao.QueryMapper;
import com.cg.qgs.exception.QGSException;
import com.cg.qgs.model.AccountBean;
import com.cg.qgs.model.BusinessSegmentBean;
import com.cg.qgs.model.LoginBean;
import com.cg.qgs.model.PolicyBean;
import com.cg.qgs.model.ReportBean;
import com.cg.qgs.utility.JdbcUtility;

public class QGSDaoImplementation implements QGSDao {
	static Logger logger = Logger.getLogger(QGSDaoImplementation.class);
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	Long policyNumber = 0l;
	
	/**
	 * Method 		: Logging into LogIn Module 
	 * Argument 	: it's taking username and password as an argument 
	 * returntype	: this method returns the list of Login Bean Object 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public List<LoginBean> loginValid(String username, String password) throws QGSException {
		logger.info("Inside LoginValid method");
		ResultSet resultSet = null;
		List<LoginBean> list = null;
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			logger.info("Inside LoginValid 1st try block");
			list = new ArrayList<>();
			preparedStatement = connection.prepareStatement(QueryMapper.loginValidation);
			logger.info("Query Executed..");
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			logger.info("ResultSet Executed");
			while (resultSet.next()) {
				logger.debug("Inside loginValid While loop 1");
				String userName = resultSet.getString(1);
				String roleCode = resultSet.getString(3);

				LoginBean bean = new LoginBean();
				bean.setUsername(userName);
				bean.setRoleCode(roleCode);

				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		try {
			resultSet.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}

		try {
			preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}

		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends login block");
		return list;
	}
	
	/**
	 * Method 		:  Validating username 
	 * Argument 	: it's taking UserName as an argument
	 * returntype	: this method returns the Boolean Value 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	
	@Override
	public boolean getValidUsername(String userName) throws QGSException {
		logger.info("Enters into the getVlaidUsername method");
		boolean userFlag = false;
		List<LoginBean> list1 = null;
		connection = JdbcUtility.getConnection();
		list1 = new ArrayList<>();
		try {
			logger.info("Inside GetValidUsername 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.userValidation);
			preparedStatement.setString(1, userName);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				logger.debug("Inside GetValidUsername While loop 1");
				String profUserName = resultSet.getString(1);
				LoginBean bean = new LoginBean();
				bean.setUsername(profUserName);
				list1.add(bean);
			}
			if (list1.isEmpty()) {
				logger.debug("Inside GetValidUsername If block 1");
				userFlag = true;

			} else {
				logger.debug("Inside GetValidUsername Else block 1");
				userFlag = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {

			try {
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("End of username validation");
		return userFlag;
	}
	
	/**
	 * Method 		: Inserting into Userrole. 
	 * Argument 	: it's taking LoginBean object as an argument 
	 * return type 	: this method returns the result Object 
	 * Author		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public int addProfile(LoginBean bean) throws QGSException {
		logger.info("Enters into add profile");
		int result = 0;
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			logger.info("Inside AddProfile 1st Try block");
			preparedStatement = connection.prepareStatement(QueryMapper.addProfile);
			preparedStatement.setString(1, bean.getUsername());
			preparedStatement.setString(2, bean.getPassword());
			preparedStatement.setString(3, bean.getRoleCode());

			result = preparedStatement.executeUpdate();
			
			connection.commit();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			// TODO Auto-generated catch block
			try {
				connection.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				// TODO Auto-generated catch block
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					logger.error(e.getMessage());
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				try {
					connection.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					logger.error(e.getMessage());
					e1.printStackTrace();
				}
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}

		}
		logger.info("Ends the add profile");
		return result;
	}
	
	/**
	 * Method 		: Validating AccountNumbers. 
	 * Argument 	: it's taking AccountNumber as an argument 
	 * return type 	: this method returns the boolean value.
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public boolean validAccountNumber(Long accountNumber) throws QGSException {
		logger.info("Enters into validAccountNumber");
		boolean validationFlag = false;
		Long accountNo = 0l;
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		List<PolicyBean> list = new ArrayList<>();
		try {
			logger.info("Inside ValidAccountNumber 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.validateAccountNumber);
			logger.info("Query Executed..");
			preparedStatement.setLong(1, accountNumber);

			resultSet = preparedStatement.executeQuery();
			logger.info("Result Set Executed..");
			while (resultSet.next()) {
				logger.debug("Inside GetValidUsername While loop 1");
				accountNo = resultSet.getLong(1);
				PolicyBean bean = new PolicyBean();

				bean.setAccountNumber(accountNo);
				list.add(bean);
			}
			if (!list.isEmpty()) {
				logger.debug("Inside GetValidUsername If Block 1");
				validationFlag = true;
			} else {
				logger.debug("Inside GetValidUsername Else Block 1");
				validationFlag = false;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				e.printStackTrace();
			}
		}
		logger.info("Ends Validate Account Number");;
		return validationFlag;
	}
	/**
	 * Method 		: Displaying BusinessSegment to User. 
	 * Argument 	: it's not taking anything as an argument 
	 * return type 	: this method returns the list of BusinessSegmentBean Object 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public List<BusinessSegmentBean> viewBusinessName() throws QGSException {
		logger.info("Enters into viewBusinessName");
		
		List<BusinessSegmentBean> list = new ArrayList<>();

		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.getBusinessName);

			resultSet = preparedStatement.executeQuery();
			logger.info("Prepared Statement is executed");
			while (resultSet.next()) {
				logger.debug("Inside ViewBusinessName While loop 1");
				String busId = resultSet.getString(1);
				String busName = resultSet.getString(3);

				BusinessSegmentBean bean = new BusinessSegmentBean();
				bean.setBusinessName(busName);
				bean.setBusinessId(busId);
				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends from viewBusinessName");
		return list;
	}
	/**
	 * Method 		: Displaying PolicyQuestions to user. 
	 * Argument 	: it's taking BusinessSegment as an argument 
	 * return type 	: this method returns the list of Policy Bean Object 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	
	@Override
	public List<PolicyBean> getPolicyQuestions(String businessSegment) throws QGSException {
		logger.info("Enters into get policy questions");
		List<PolicyBean> list = null;

		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			logger.info("Inside GetPolicyQuestions 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.getPolicyQuestions);
			logger.info("Query Executed..");
			preparedStatement.setString(1, businessSegment);
			resultSet = preparedStatement.executeQuery();
			logger.info("ResultSet Executed");
			list = new ArrayList<>();
			while (resultSet.next()) {
				logger.debug("Inside GetPolicyQuestions While loop 1");
				String policyQuesId = resultSet.getString(1);
				String question = resultSet.getString(4);
				String answerOne = resultSet.getString(5);
				int answerOneWeightage = resultSet.getInt(6);
				String answerTwo = resultSet.getString(7);
				int answerTwoWeightage = resultSet.getInt(8);
				String answerThree = resultSet.getString(9);
				int answerThreeWeightage = resultSet.getInt(10);

				PolicyBean bean = new PolicyBean();
				bean.setPolicyQuestionId(policyQuesId);
				bean.setQuestion(question);
				bean.setAnswerOne(answerOne);
				bean.setAnswerTwo(answerTwo);
				bean.setAnswerThree(answerThree);
				bean.setAnsOneWeightage(answerOneWeightage);
				bean.setAnsTwoWeightage(answerTwoWeightage);
				bean.setAnsThreeWeightage(answerThreeWeightage);

				list.add(bean);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends into get policy questions");
		return list;
	}
	/**
	 * Method 		: Generating policy using Policy Number. 
	 * Argument 	: it's taking PolicyBean Object as an argument 
	 * return type 	: this method returns the Generated Policy 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public long generatePolicy(PolicyBean bean) throws QGSException {
		logger.info("Enters into Policy Generation");
		long result = 0l;

		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			logger.info("Inside GeneratePolicy 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.generatePolicy);
			logger.info("Query Executed..");
			preparedStatement.setDouble(1, bean.getPolicyPremium());
			preparedStatement.setLong(2, bean.getAccountNumber());
			preparedStatement.setString(3, bean.getBusinessId());

			preparedStatement.executeUpdate();
			logger.info("PreparedStatement Executed");
			preparedStatement = connection.prepareStatement(QueryMapper.getPolicyNumber);
			resultSet = preparedStatement.executeQuery();
			logger.info("ResultSet Executed");
			while (resultSet.next())
				logger.debug("Inside GeneratePolicy While loop 1");
				result = resultSet.getLong(1);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends from Policy Generation");
		return result;
	}
	/**
	 * Method 		: Inserting into PolicyDetails. 
	 * Argument 	: it's taking PolicyBean Object as an argument 
	 * return type 	: this method returns the list of Policy Bean Object 
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public int policyDetails(PolicyBean beans) throws QGSException {
		logger.info("Enters into Policy Details");
		int result = 0;
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			logger.info("Inside PolicyDetails 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.insertPolicyDetails);
			logger.info("Query Executed..");
			preparedStatement.setLong(1, beans.getPolicyNumber());
			preparedStatement.setString(2, beans.getQuestionDetails());
			preparedStatement.setString(3, beans.getAnswerDetails());

			result = preparedStatement.executeUpdate();
			logger.info("ResultSet Executed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("ends  from policy details");
		return result;
	}

	/**
	 * Method : Inserting into Accounts Table. 
	 * Argument : it's taking AccountBeans Object as an argument 
	 * return type : this method returns the list of AccountBean Object 
	 * Author : Capgemini 
	 * Date : 08-Feb-2019
	 */
	
	
	@Override
	public long addAccount(AccountBean accountBean) throws QGSException {
		logger.info("Enters into Add Accounts");
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		int result = 0;
		long accountNumber = 0;
		try {
			logger.info("Inside LoginValid 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.addAccount);
			logger.info("Query Executed..");
			preparedStatement.setString(1, accountBean.getInsuredName());
			preparedStatement.setString(2, accountBean.getInsuredStreet());
			preparedStatement.setString(3, accountBean.getInsuredCity());
			preparedStatement.setString(4, accountBean.getInsuredState());
			preparedStatement.setLong(5, accountBean.getInsuredZip());
			preparedStatement.setString(6, accountBean.getUserName());

			result = preparedStatement.executeUpdate();
			logger.info("ResultSet Executed");
			if (result == 1) {
				logger.info("Inside GetValidUsername If block");
				preparedStatement = connection.prepareStatement(QueryMapper.getAccountNumber);
				resultSet = preparedStatement.executeQuery();
				resultSet.next();
				accountNumber = resultSet.getLong(1);
			} else {
				logger.info("Inside GetValidUsername Else block");
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				try {
					connection.rollback();
				} catch (SQLException e1) {
					logger.error(e1.getMessage());
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				try {
					connection.rollback();
				} catch (SQLException e1) {
					logger.error(e1.getMessage());
					e1.printStackTrace();
				}
				e.printStackTrace();
			}

		}
		logger.info("Ends from Add Accounts");
		return accountNumber;
	}
	
	/**
	 * Method 		: Displaying Policy details of specific User based on AccountNumber.
	 * Argument 	: it's taking AccountNumber as an argument 
	 * return type 	: this method returns the list of Policy Bean Object 
	 * Author 		: Capgemini 
	 * Date			: 08-Feb-2019
	 */
	
	@Override
	public List<PolicyBean> getDetails(long accountNumber) throws QGSException {
		logger.info("Enters into Get policy Details");
		List<PolicyBean> list = new ArrayList<>();

		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.getDetails);
			logger.info("Inside GetDetails 1st try block");
			preparedStatement.setLong(1, accountNumber);
			
			resultSet = preparedStatement.executeQuery();
			logger.info("ResultSet Executed");
			while (resultSet.next()) {
				logger.debug("Inside GetDetails While loop 1");
				long policyNumber = resultSet.getLong(1);
				double policyPremium = resultSet.getLong(2);
				long accountNumber1 = resultSet.getLong(3);
				String businessSegment = resultSet.getString(4);
				PolicyBean policyModel = new PolicyBean();
				policyModel.setPolicyNumber(policyNumber);
				policyModel.setPolicyPremium(policyPremium);
				policyModel.setAccountNumber(accountNumber1);
				policyModel.setBusinessId(businessSegment);
				list.add(policyModel);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {
			logger.info("Inside GetDetails Finally block");
			try {
				preparedStatement.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				try {
					connection.rollback();
				} catch (SQLException e1) {
					logger.error(e.getMessage());
					e1.printStackTrace();
				}
				e.printStackTrace();
			}
			try {
				connection.close();

			} catch (SQLException e) {
				logger.error(e.getMessage());
				try {
					connection.rollback();
				} catch (SQLException e1) {
					logger.error(e.getMessage());
					e1.printStackTrace();
				}
				e.printStackTrace();
			}

		}
		logger.info("Ends from get policy details");
		return list;
	}
	/**
	 * Method 		: Genarate Report for Policy 
	 * Argument 	: it's taking accountNumber as an argument 
	 * return type 	: this method returns list of ReportBean
	 * Author 		: Capgemini 
	 * Date 		: 08-Feb-2019
	 */
	@Override
	public List<ReportBean> reportGeneration(long accountNumber) throws QGSException {
	logger.info("Enters into Report Generation");
		
		connection = JdbcUtility.getConnection();
		logger.info("Connection is established");
		ResultSet resultSet = null;
		
		List<ReportBean> list = new ArrayList<>();
		try {
			logger.info("Inside reportGeneration 1st try block");
			preparedStatement = connection.prepareStatement(QueryMapper.detailedReport);
			logger.info("Query Executed..");
			preparedStatement.setLong(1, accountNumber);
			resultSet = preparedStatement.executeQuery();
			logger.info("ResultSet Executed");
			while (resultSet.next()) {
				logger.debug("Inside reportGeneration While loop 1");
				String insuredName = resultSet.getString(1);
				String insuredStreet = resultSet.getString(2);
				String insuredCity = resultSet.getString(3);
				String insuredState = resultSet.getString(4);
				Long insuredZip = resultSet.getLong(5);
				String businessName = resultSet.getString(6);
				Double policyPremium = resultSet.getDouble(7);
				String question = resultSet.getString(8);
				String answerDetails = resultSet.getString(9);

				ReportBean reportBean = new ReportBean();
				reportBean.setInsuredName(insuredName);
				reportBean.setInsuredStreet(insuredStreet);
				reportBean.setInsuredCity(insuredCity);
				reportBean.setInsuredState(insuredState);
				reportBean.setInsuredZip(insuredZip);
				reportBean.setBusinessName(businessName);
				reportBean.setPolicyPremium(policyPremium);
				reportBean.setQuestion(question);
				reportBean.setAnswerDetails(answerDetails);
				list.add(reportBean);

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends from Report Generation");
		return list;
	}

	// ---------------------------------------------------USER--------------------------------------------------------------------------
	/**
	 * Method       : Inserting into newAccount.
	 * Argument     : it's taking AccountBean object as an argument
	 * return type  : this method returns the result long account number 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */ 
	@Override
	public long newAccount(AccountBean accountCreation) throws QGSException {

		logger.info("Control comes into newAccount Method");
		connection = JdbcUtility.getConnection();
		long accountNum = 0l;

		try {
			logger.info("connection is established");
			preparedStatement = connection.prepareStatement(QueryMapper.insertQuery);

			preparedStatement.setString(1, accountCreation.getInsuredName());
			preparedStatement.setString(2, accountCreation.getInsuredStreet());
			preparedStatement.setString(3, accountCreation.getInsuredCity());
			preparedStatement.setString(4, accountCreation.getInsuredState());
			preparedStatement.setLong(5, accountCreation.getInsuredZip());
			preparedStatement.setString(6, accountCreation.getUserName());
			preparedStatement.executeUpdate();
			logger.info("prepared statement is executed for inserting into accounts table");

			preparedStatement = connection.prepareStatement(QueryMapper.viewAccountNum);
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared statement is executed for viewing account number");

			while (resultSet.next()) {
				accountNum = resultSet.getLong(1);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			// throw new InsuranceException("Not Inserted");
			e.printStackTrace();
		}
		try {
			resultSet.close();
		} catch (SQLException e) {
			
			logger.error(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			connection.close();
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("End of Account Creation newAccount Method");
		return accountNum;
	}
	/**
	 * Method       : getting policy from viewPolicy
	 * Argument     : it's taking String username as an argument
	 * return type  : this method returns the List with type Policy Bean which has policy details inside it 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	@Override
	public List<PolicyBean> viewPolicy(String username) throws QGSException {
		logger.info("control comes into viewPolicy Method");
		List<PolicyBean> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		try {
			logger.info("Connection established");
			preparedStatement = connection.prepareStatement(QueryMapper.viewPolicy);
			preparedStatement.setString(1, username);
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared statement is executed for view policy");
			while (resultSet.next()) {

				String businessSegment = resultSet.getString(4);
				long policyNumber = resultSet.getLong(1);
				double policyPremium = resultSet.getDouble(2);
				long accountNumber = resultSet.getLong(3);

				PolicyBean policy = new PolicyBean();

				policy.setBusinessId(businessSegment);
				policy.setPolicyNumber(policyNumber);
				policy.setPolicyPremium(policyPremium);
				policy.setAccountNumber(accountNumber);

				list.add(policy);
				logger.debug("details are added into list"+list);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("ended the view policy");
		return list;
	}
	/**
	 * Method       : checking account number from checkAccountCreation
	 * Argument     : it's taking String username as an argument
	 * return type  : this method returns boolean if the account exists or not 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	@Override
	public boolean checkAccountCreation(String username) throws QGSException {
		logger.info("enters into checkAccountCreation method");
		boolean result = false;
		connection = JdbcUtility.getConnection();
		logger.info("Connection established");
		List<AccountBean> list = new ArrayList<>();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.checkAccount);
			preparedStatement.setString(1, username);
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared statement is executed for checking account");
			while (resultSet.next()) {
				AccountBean accountBean = new AccountBean();
				accountBean.setUserName(resultSet.getString(1));
				list.add(accountBean);
				logger.debug("list is added form response"+list);
			}
			if (!list.isEmpty()) {
				logger.info("the list is not empty");
				result = false;
			} else {
				logger.info("the list is empty");
				result = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("End of the checking account method");
		return result;
	}

	
	
	// ---------------------------------------------------------------------AGENT-----------------------------------------------------------------
	
	/**
	 * Method       : inserting into account details using getInsertion 
	 * Argument     : it's taking AccountBean object as an argument
	 * return type  : this method returns long account number after insertion
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public long getInsertion(AccountBean accountBean) throws QGSException {
		logger.info("Account creation method using AGENT ");
		long account = 0l;
		connection = JdbcUtility.getConnection();
		logger.info("Connection established");
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.getinsertrecord);
			preparedStatement.setString(1, accountBean.getInsuredName());
			preparedStatement.setString(2, accountBean.getInsuredStreet());
			preparedStatement.setString(3, accountBean.getInsuredCity());
			preparedStatement.setString(4, accountBean.getInsuredState());
			preparedStatement.setLong(5, accountBean.getInsuredZip());
			preparedStatement.setString(6, accountBean.getUserName());

			preparedStatement.executeUpdate();
			logger.info("Prepared Statement for account creation");
			preparedStatement = connection.prepareStatement(QueryMapper.viewAccountNo);
			
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared stated executed for getting account number");
			
			resultSet.next();
			account = resultSet.getLong(1);
			logger.info("details in account to fetch the account number");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("Result Set not closed");
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("statment not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("Connection not closed");
			}
		}
		logger.info("Ends the account creation method");
		return account;
	}
	
	/**
	 * Method       : getting business names from viewBusinessSegment
	 * Argument     : no argument
	 * return type  : this method returns List with BusinessSegmentBean as Type and business details in it
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	@Override
	public List<BusinessSegmentBean> viewBusinessSegment() throws QGSException {
		logger.info("Enters into viewBusinessSegment method");
		connection = JdbcUtility.getConnection();
		logger.info("Connection Estabished");
		List<BusinessSegmentBean> list = new ArrayList<>();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.viewBusinessSegment);
			resultSet = preparedStatement.executeQuery();
			logger.info("Prepared statement is executed to view the business segment");
			while (resultSet.next()) {
				
				String busSegName = resultSet.getString(1);
				BusinessSegmentBean businessSegment = new BusinessSegmentBean();
				businessSegment.setBusinessName(busSegName);
				list.add(businessSegment);
				logger.debug("getting the business segment "+list);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.debug(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends the view business segment method");
		return list;
	}
	
	/**
	 * Method       : checking account number if its valid using checkingAccount
	 * Argument     : it takes Long account number as an argument
	 * return type  : this method returns boolean if the account exists or not
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public boolean checkingAccount(Long accountNumber) throws QGSException {
		logger.info("Checking if the account number is correct");
		connection = JdbcUtility.getConnection();
		logger.info("Connection Estabished");
		boolean flag = false;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.displayAccountNo);
			resultSet = preparedStatement.executeQuery();
			logger.info("Prepared statement is executed");
			while (resultSet.next()) {
				if (resultSet.getLong(1) == accountNumber) {
					flag = true;
					logger.debug("account number is present"+flag);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends the account number checking method");
		return flag;
	}

	/**
	 * Method       : getting the policy details from viewPolicyDetails
	 * Argument     : it takes String businessSegment as an argument
	 * return type  : this method returns List of type PolicyBean gives the policy details 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public List<PolicyBean> viewPolicyDetails(String businessSegment) throws QGSException {
		logger.info("Enters into view Policy Details getting questions and ansers and getting premium");
		
		connection = JdbcUtility.getConnection();
		logger.info("connection is established");
		List<PolicyBean> list = null;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.viewPolicyDetails);
			preparedStatement.setString(1, businessSegment);
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared statement is executed to get the questiosn to pretaining business segment");
			list = new ArrayList<>();
			while (resultSet.next()) {

				String policyQuestId = resultSet.getString(1);
				String question = resultSet.getString(4);
				String answerOne = resultSet.getString(5);
				int answerOneWeight = resultSet.getInt(6);
				String answerTwo = resultSet.getString(7);
				int answerTwoWeight = resultSet.getInt(8);
				String answerThree = resultSet.getString(9);
				int answerThreeWeight = resultSet.getInt(10);

				PolicyBean policyquestions = new PolicyBean();
				// policyquestions.setBuisnessSegement("Business Auto");
				policyquestions.setPolicyQuestionId(policyQuestId);
				policyquestions.setQuestion(question);
				policyquestions.setAnswerOne(answerOne);
				policyquestions.setAnswerTwo(answerTwo);
				policyquestions.setAnswerThree(answerThree);
				policyquestions.setAnsOneWeightage(answerOneWeight);
				policyquestions.setAnsTwoWeightage(answerTwoWeight);
				policyquestions.setAnsThreeWeightage(answerThreeWeight);

				list.add(policyquestions);		
				logger.info("List is loaded with questions and answers" +list);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		logger.info("Ends the viewPolicyDetails method");
		return list;
	}

	/**
	 * Method       : inserting into the policy from viewPolicyDetails
	 * Argument     : it takes PolicyBean as Object as an argument
	 * return type  : this method returns int policy number 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public int insertPolicy(PolicyBean questions) throws QGSException {
		logger.info("Enters into insert policy into policy details method");
		int result = 0;

		connection = JdbcUtility.getConnection();
		logger.info("connection is established");
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.getinsertPolicy);
			preparedStatement.setDouble(1, questions.getPolicyPremium());
			preparedStatement.setLong(2, questions.getAccountNumber());
			preparedStatement.setString(3, questions.getBusinessId());

			result = preparedStatement.executeUpdate();
			logger.info("preparedStatement is executed to insert into policy table");
			preparedStatement = connection.prepareStatement(QueryMapper.displayPolicyNo);
			resultSet = preparedStatement.executeQuery();
			logger.info("prepared statement is executed to get the policy number");
			
			resultSet.next();
			policyNumber = resultSet.getLong(1);
			logger.info("policy number is " +policyNumber);
		
		} catch (SQLException e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			/* throw new QGSException("Prepared statement not created "); */
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e1) {
				logger.error(e1.getMessage());
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("Connection not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("statment not closed");
			}
		}
		logger.info("Ends from policy details method");
		return result;
	}

	/**
	 * Method       : inserting into the policy details from insertIntoPolicyDetails
	 * Argument     : it takes List as an object with policy bean as an argument
	 * return type  : this method returns int policy details added 
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public int insertIntoPolicyDetails(List<PolicyBean> questions2) throws QGSException {
		logger.info("Enters into insertIntoPolicyDetails method to save the policy details table");
		int result = 0;
		connection = JdbcUtility.getConnection();
		logger.info("connection established");
		try {

			for (PolicyBean details : questions2) {
				preparedStatement = connection.prepareStatement(QueryMapper.insertIntoPolicyDetails);
				preparedStatement.setLong(1, policyNumber);
				preparedStatement.setString(2, details.getPolicyQuestionId());
				preparedStatement.setString(3, details.getAnswerDetails());
				result = preparedStatement.executeUpdate();
				logger.debug("prepared statement is executed for question id and answer inside the forEach loop");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new QGSException("Prepared statement not created ");
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());	
				throw new QGSException("Connection not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("statment not closed");
			}
		}
		logger.info("ends the insertIntoPolicyDetails method"+result);
		return result;
	}

	/**
	 * Method       : getting the policy list from getViewPolicy
	 * Argument     : it takes String username as argument
	 * return type  : this method returns List as an object with policy bean  
	 * Author       : Capgemini 
	 * Date         : 11-Feb-2019 
	 */
	
	@Override
	public List<PolicyBean> getViewPolicy(String username) throws QGSException {
		logger.info("enters into getViewPolicy method");
		List<PolicyBean> list = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("Connection Established");
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.selectPolicy);
			preparedStatement.setString(1, username);
			resultSet = preparedStatement.executeQuery();
			logger.info("Prepared Statement is executed to view policy");
			while (resultSet.next()) {
				String businessSegement = resultSet.getString("BUSINESS_SEGMENT");
				Long accountNumber = resultSet.getLong("ACCOUNT_NUMBER");
				Long policyNumber = resultSet.getLong("POLICY_NUMBER");
				Double policyPremium = resultSet.getDouble("POLICY_PREMIUM");

				PolicyBean policy = new PolicyBean();

				policy.setBusinessId(businessSegement);
				policy.setAccountNumber(accountNumber);
				policy.setPolicyNumber(policyNumber);
				policy.setPolicyPremium(policyPremium);

				list.add(policy);
				logger.debug("list is loaded with the policy details for the given agent has" +list);
			}

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new QGSException("Connection is not closed");
		}

		finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("Statement not closed");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new QGSException("Connection not closed");
			}
		}
		logger.info("ends the getViewPolicy");
		return list;
	}
}
